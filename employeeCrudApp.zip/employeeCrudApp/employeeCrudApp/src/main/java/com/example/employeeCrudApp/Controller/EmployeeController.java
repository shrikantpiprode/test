package com.example.employeeCrudApp.Controller;

import java.util.List;

import com.example.employeeCrudApp.exception.ResourceNotFoundException;
import com.example.employeeCrudApp.model.Employee;
import com.example.employeeCrudApp.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    // get all employee
    @GetMapping
    public List<Employee> getAllEmployees() {
        return this.employeeRepository.findAll();
    }

    // get employee by id
    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable (value = "id") long id) {
        return this.employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id :" + id));
    }

    // create employee
    @PostMapping
    public Employee createEmployee(@RequestBody Employee employee) {
        return this.employeeRepository.save(employee);
    }

    // update emp
    @PutMapping("/{id}")
    public Employee updateEmployee(@RequestBody Employee emp, @PathVariable ("id") long id) {
        Employee existingEmployee = this.employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id :" + id));
        existingEmployee.setFirst_name(emp.getFirst_name());
        existingEmployee.setLast_name(emp.getLast_name());
        existingEmployee.setEmail(emp.getEmail());
        existingEmployee.setPhone(emp.getPhone());
        return this.employeeRepository.save(existingEmployee);
    }

    // delete employee by id
    @DeleteMapping("/{id}")
    public ResponseEntity<Employee> deleteEmployee(@PathVariable ("id") long id){
        Employee existingEmployee= this.employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id :" + id));
        this.employeeRepository.delete(existingEmployee);
        return ResponseEntity.ok().build();
    }
}
