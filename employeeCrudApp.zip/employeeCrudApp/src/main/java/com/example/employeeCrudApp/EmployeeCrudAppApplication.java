package com.example.employeeCrudApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeCrudAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeCrudAppApplication.class, args);
	}

}
