package com.example.employeeCrudApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCrudAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
